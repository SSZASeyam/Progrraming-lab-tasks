#include <bits/stdc++.h>
using namespace std;
//Factorial function make
int fact (int n){
int factorial=1;
for (int i =2 ; i<=n ; i++){
    factorial=factorial*i;
}
return factorial;
}
int main() {
    int n;
    cout<< "Enter a number : ";
    cin>> n;
    int ans = fact(n);
    cout<<"The factorial of "<< n<< " is "<<ans << endl;
    int r ;
    cout<< "Enter n value : ";
    cin>>n;
    cout<< "Enter r value : ";
    cin>>r;
    // Combination thats we call nCr
    int nCr = fact(n)/(fact(n-r)*fact(r));
    cout <<"The Combination or  nCr is : "<< nCr <<endl;
    //Permutation thats we call nPr
    int nPr = fact(n)/(fact(n-r)) ;
    cout<< "The Permutation or nPr is : "<<nPr<<endl;
    return 0;
}

